.. cmake-module:: ../../Modules/FindOpenCL.cmake
